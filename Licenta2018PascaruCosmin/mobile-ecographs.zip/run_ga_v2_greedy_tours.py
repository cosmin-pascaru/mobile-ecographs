from src.ga_v2_greedy_tours.solver import run as run_ga_v2, run_test_permutation_evaluation


# run_test_permutation_evaluation()
run_ga_v2()