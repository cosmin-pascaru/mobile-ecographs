class ManagerParams:
    def __init__(self):
        self.debug = False
        self.maps_api_key = None

        self.index_template_file = None
        self.tour_template_file = None
