class PlannerParams:
    def __init__(self):
        self.debug           = False
        self.write_best_plan = False
        self.cnt_iterations  = 1
        self.keep_percent    = None
