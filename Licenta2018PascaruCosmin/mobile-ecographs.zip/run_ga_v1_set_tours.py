from src.ga_v1_set_tours.solver import run as run_ga_v1

run_ga_v1()
