
def debug (*args, **kwargs):
    print(*args, **kwargs)
